const express = require('express');

const app = express();

app.get('/' , (request, response)=>{
    return response.json({message: "Olá mundo ignite!"})
})

//localhost<porta>
app.listen(3333);